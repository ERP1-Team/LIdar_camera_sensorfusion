#!/usr/bin/env python
import rospy
from sensor_msgs.msg import NavSatFix
from geometry_msgs.msg import Point
from sensor_fu.msg import matched_object_msg_arr, matched_object_msg  # Import the custom messages
import pyproj
from pyproj import Transformer

class SensorFusionNode:
    def __init__(self):
        rospy.init_node('sensor_fusion_node')

        self.utm_data = None

        rospy.Subscriber('/utm_coordinates', Point, self.utm_callback)  # Subscribe to UTM coordinates
        rospy.Subscriber('/matched_objects', matched_object_msg_arr, self.lidar_callback)

        self.pub = rospy.Publisher('/transformed_objects', matched_object_msg_arr, queue_size=10)  # Publisher for transformed data

        rospy.spin()

    def utm_callback(self, msg):
        self.utm_data = msg

    def lidar_callback(self, msg):
        if self.utm_data is None:
            rospy.logwarn("No UTM data received yet.")
            return

        # UTM reference data
        utm_x_ref = self.utm_data.x
        utm_y_ref = self.utm_data.y
        utm_z_ref = self.utm_data.z

        # Translation vector from Lidar to GPS
        translation_vector = [0.20, 0.13, -0.12]  # Lidar to GPS translation vector

        # Initialize transformed object list
        transformed_objects = matched_object_msg_arr()

        # Transform and store Lidar data
        for obj in msg.objects:
            # Apply translation to Lidar data
            lidar_data_world = [obj.lidar_x + translation_vector[0], obj.lidar_y + translation_vector[1], obj.lidar_z + translation_vector[2]]

            # Convert Lidar data to UTM coordinates
            lidar_data_utm = [
                utm_x_ref + lidar_data_world[0],
                utm_y_ref + lidar_data_world[1],
                utm_z_ref + lidar_data_world[2]
            ]

            # Create transformed object and set data
            transformed_obj = matched_object_msg()
            transformed_obj.class_name = obj.class_name
            transformed_obj.lidar_x = lidar_data_utm[0]
            transformed_obj.lidar_y = lidar_data_utm[1]
            transformed_obj.lidar_z = lidar_data_utm[2]
            transformed_obj.distance = obj.distance

            # Add transformed object to the list
            transformed_objects.objects.append(transformed_obj)

        # Publish transformed data
        transformed_objects.objects = sorted(transformed_objects.objects, key=lambda obj: obj.distance)
        self.pub.publish(transformed_objects)

if __name__ == '__main__':
    try:
        SensorFusionNode()
    except rospy.ROSInterruptException:
        pass

