#!/usr/bin/env python

import rospy
import cv2
import datetime
from ultralytics import YOLO
from sensor_msgs.msg import Image
from std_msgs.msg import Header, String
from cv_bridge import CvBridge, CvBridgeError
from yolo_v8_msgs.msg import yolo_bbox, yolo_bbox_arr  # Import the new YOLO message types

model = YOLO('yolov8n.pt')
sequence_number = 0

class Camera:
    def __init__(self):
        self.image_sub = rospy.Subscriber("/zed2i/zed_node/rgb/image_rect_color", Image, self.callback)
        self.bridge = CvBridge()
        self.cv_image = None
        self.WIDTH = 640
        self.HEIGHT = 360

    def callback(self, data):
        try:
            self.cv_image = self.bridge.imgmsg_to_cv2(data, "bgr8")
        except CvBridgeError as e:
            rospy.logerr(f"CvBridge Error: {e}")

    def show(self):
        save_txt_pub = rospy.Publisher("/data_sender/classes", String, queue_size=10)
        image_pub = rospy.Publisher("/yolov8/img", Image, queue_size=10)
        bbox_pub = rospy.Publisher("/yolov8/bboxes", yolo_bbox_arr, queue_size=10)  # New publisher for bounding boxes
        rate = rospy.Rate(10)  # 10Hz

        global sequence_number

        while not rospy.is_shutdown():
            frame = self.cv_image
            if frame is not None:
                results = model.track(frame, persist=True, imgsz=self.WIDTH)
                annotated_frame = results[0].plot()
                cv2.imshow("YOLOv8 Tracking", annotated_frame)

                # 메시지 생성
                sequence_number += 1
                header = Header()
                header.stamp = rospy.Time.now()
                header.seq = sequence_number

                save_txt = ""
                bboxes = yolo_bbox_arr()  # Create a new instance of the bounding box array message

                try:
                    for i in range(len(results[0].boxes.cls)):
                        class_id = int(results[0].boxes.cls[i])
                        class_name = model.names[class_id]
                        coordinates = results[0].boxes.xyxy[i].numpy().astype(int).tolist()
                        confidence = results[0].boxes.conf[i].numpy()
                        save_txt += f"{class_name}-[{coordinates[0]}, {coordinates[1]}, {coordinates[2]}, {coordinates[3]}]-{confidence:.2f}/"

                        # Convert detection to the yolo_bbox message format
                        bbox = yolo_bbox()
                        bbox.class_name = class_name  # Use class name directly
                        bbox.xMin = float(coordinates[0])
                        bbox.yMin = float(coordinates[1])
                        bbox.xMax = float(coordinates[2])
                        bbox.yMax = float(coordinates[3])
                        bbox.confidence = float(confidence)
                        bboxes.bboxes.append(bbox)

                except Exception as e:
                    rospy.logerr(f"Error processing detection results: {e}")

                # 문자열 메시지 퍼블리시
                save_txt_pub.publish(save_txt)

                # 이미지 메시지 퍼블리시
                try:
                    detection_image_msg = self.bridge.cv2_to_imgmsg(annotated_frame, "bgr8")
                    image_pub.publish(detection_image_msg)
                    bbox_pub.publish(bboxes)  # Publish the bounding boxes
                except CvBridgeError as e:
                    rospy.logerr(f"CvBridge Error: {e}")

            key = cv2.waitKey(1)
            if key == ord('q'):
                self.release()
                cv2.destroyAllWindows()
                rospy.signal_shutdown("User requested shutdown")
                break
            rate.sleep()

    def release(self):
        cv2.destroyAllWindows()

if __name__ == '__main__':
    rospy.init_node('cam', anonymous=True)
    cam = Camera()
    cam.show()

