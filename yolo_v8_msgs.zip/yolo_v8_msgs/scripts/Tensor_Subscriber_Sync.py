#!/usr/bin/env python

import rospy
import message_filters
from yolo_v8_msgs.msg import Tensor
import torch

def callback(cls_data, conf_data, id_data, xywh_data, xywhn_data, xyxy_data, xyxyn_data):
    try:
        cls_shape = tuple(cls_data.shape)
        cls_tensor = torch.tensor(cls_data.data, dtype=torch.float32).view(cls_shape)
        rospy.loginfo(f"cls data (seq: {cls_data.header.seq}): {cls_tensor}")
        
        conf_shape = tuple(conf_data.shape)
        conf_tensor = torch.tensor(conf_data.data, dtype=torch.float32).view(conf_shape)
        rospy.loginfo(f"conf data (seq: {conf_data.header.seq}): {conf_tensor}")
        
        id_shape = tuple(id_data.shape)
        id_tensor = torch.tensor(id_data.data, dtype=torch.float32).view(id_shape)
        rospy.loginfo(f"id data (seq: {id_data.header.seq}): {id_tensor}")
        
        xywh_shape = tuple(xywh_data.shape)
        xywh_tensor = torch.tensor(xywh_data.data, dtype=torch.float32).view(xywh_shape)
        rospy.loginfo(f"xywh data (seq: {xywh_data.header.seq}): {xywh_tensor}")
        
        xywhn_shape = tuple(xywhn_data.shape)
        xywhn_tensor = torch.tensor(xywhn_data.data, dtype=torch.float32).view(xywhn_shape)
        rospy.loginfo(f"xywhn data (seq: {xywhn_data.header.seq}): {xywhn_tensor}")
        
        xyxy_shape = tuple(xyxy_data.shape)
        xyxy_tensor = torch.tensor(xyxy_data.data, dtype=torch.float32).view(xyxy_shape)
        rospy.loginfo(f"xyxy data (seq: {xyxy_data.header.seq}): {xyxy_tensor}")
        
        xyxyn_shape = tuple(xyxyn_data.shape)
        xyxyn_tensor = torch.tensor(xyxyn_data.data, dtype=torch.float32).view(xyxyn_shape)
        rospy.loginfo(f"xyxyn data (seq: {xyxyn_data.header.seq}): {xyxyn_tensor}")
        print('\n')

    except Exception as e:
        rospy.logwarn(f"Data processing error: {e}")

def tensor_subscriber():
    rospy.init_node('tensor_subscriber_node', anonymous=True)
    
    cls_sub = message_filters.Subscriber('cls_topic', Tensor)
    conf_sub = message_filters.Subscriber('conf_topic', Tensor)
    id_sub = message_filters.Subscriber('id_topic', Tensor)
    xywh_sub = message_filters.Subscriber('xywh_topic', Tensor)
    xywhn_sub = message_filters.Subscriber('xywhn_topic', Tensor)
    xyxy_sub = message_filters.Subscriber('xyxy_topic', Tensor)
    xyxyn_sub = message_filters.Subscriber('xyxyn_topic', Tensor)
    
    ts = message_filters.ApproximateTimeSynchronizer(
        [cls_sub, conf_sub, id_sub, xywh_sub, xywhn_sub, xyxy_sub, xyxyn_sub], 
        queue_size=10, 
        slop=0.1
    )
    ts.registerCallback(callback)

    rospy.spin()

if __name__ == '__main__':
    tensor_subscriber()
